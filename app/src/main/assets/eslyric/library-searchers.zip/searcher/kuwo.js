﻿
/**
 * ESLyric Sample Search Service
 * Docs: https://github.com/ESLyric/release/wiki
 */

export function getLyrics(meta, man) {
    // 构造搜索请求
    const url = `https://www.kuwo.cn/api/www/search/searchMusicBykeyWord?key=${encodeURIComponent(meta.title + ' ' + meta.artist)}`;
    
    // 发送请求
    request({ url, headers: { Referer: 'https://www.kuwo.cn' } }, (err, res, body) => {
        if (err || res.statusCode !== 200) return;
        
        // 解析JSON结果
        const data = JSON.parse(body);
        const song = data.data.list[0]; // 取首条结果
        
        // 调用歌词获取接口
        const lyricUrl = `https://www.kuwo.cn/url?format=lrc&rid=${song.rid}&response=url`;
        request({ url: lyricUrl }, (err, res, body) => {
            if (err || res.statusCode !== 200) return;
            
            // 解析LRC歌词
            const lrc = body.match(/\[offset:\d+\]\n([\s\S]+)/)[1];
            const lyricMeta = man.createLyric();
            lyricMeta.lyricText = lrc;
            man.addLyric(lyricMeta);
        });
    });
}
