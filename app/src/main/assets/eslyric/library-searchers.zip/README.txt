Legacy ESLyric searchers extracted from eslscripts.zip
